var express=require('express');
var router = express.Router();
var fs=require('fs');

var cors=require('cors');
router.use(cors());

let courseData=JSON.parse(fs.readFileSync('courses.json'));

// Sending json file to the frontend
router.get('/getCourses',(req,res)=>{
        res.send(courseData);
});

//Searching for id
router.get('/searchCourse/:id',(req,res)=>{
    let c;
    for(c of courseData){
       if(c.id==req.params['id']){
           break;
       }
   }
        res.send(c);
});


//Adding new data to the json file
router.post('/addCourse',(req,res,next)=>{
    var newCourse={
        "id":req.body.id,
        "name": req.body.name,
        "price":req.body.price,
        "duration":req.body.duration,
        "time":req.body.time
    }
    courseData.push(newCourse);
    let data=JSON.stringify(courseData,null,2);
    fs.writeFileSync('courses.json',data);
    res.send(courseData);
});


//Updating course Data based on course id
router.put('/updateCourse',(req,res,next)=>{
   for(let c of courseData){
       if(c.id==req.body.id){
           c.name=req.body.name;
           c.price=req.body.price;
           c.duration=req.body.duration;
           c.time=req.body.time;
           break;
       }
   }
   let data=JSON.stringify(courseData,null,2);
   fs.writeFileSync('courses.json',data);
   res.send(courseData);
});

//Deleting course Data based on course Id
router.delete('/delete/:id',(req,res,next)=>{
    let course;
    for(let c of courseData){
        if(c.id==req.params['id']){
            var i=courseData.indexOf(c);
            courseData.splice(i,1);
            break;
        }
    }
    let data=JSON.stringify(courseData,null,2);
    fs.writeFileSync('courses.json',data);
    res.send(courseData);
});

module.exports=router;