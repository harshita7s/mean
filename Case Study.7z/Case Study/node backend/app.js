var http=require('http');

var express=require('express');
var app=express();

var cors=require('cors');

var bodyParser=require('body-parser');
app.use(bodyParser.urlencoded({extended:false}));
app.use(bodyParser.json());


var appRoutes=require('./courses.route');


app.use('/',appRoutes);
app.use(cors());

var port=parseInt(process.env.PORT) || 3000;
http.createServer(app).listen(port);


console.log("Backend is running on port no. "+port);