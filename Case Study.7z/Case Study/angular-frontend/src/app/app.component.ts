import { Component,OnInit } from '@angular/core';
import {COURSE} from './course';
import {CourseServiceService} from './course-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  updateId:number;
  courseData:COURSE[]=[];
  child:COURSE={
    id:null,
    name:"",
    price:null,
    duration:null,
    time:""
  };
  constructor(private courseService:CourseServiceService){}

  ngOnInit(){
    this.getCourseData();
  }
  getCourseData(){
    console.log("Get course data called");
    this.courseService.getCourseData().subscribe((data)=>{this.courseData=data});
  }

  deleteCourse(id){
    console.log("Update course data called");
    this.courseService.deleteCourse(id).subscribe((data)=>{this.courseData=data});
  }

  updateCourse(c:COURSE){
      this.child.id=c.id;
      this.child.name=c.name;
      this.child.price=c.price;
      this.child.duration=c.duration;
      this.child.time=c.time;
      // this.courseService.updateCourseData(this.child.id,this.child.name,this.child.price,this.child.duration,this.child.time);
  }

  update($event) {
    this.child = $event
    this.courseService.updateCourseData(this.child.id,this.child.name,this.child.price,this.child.duration,this.child.time).subscribe((data)=>{this.courseData=data});
  }
}
