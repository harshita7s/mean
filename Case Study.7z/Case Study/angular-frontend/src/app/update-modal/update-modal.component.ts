import { Component, OnInit, Input,Output, EventEmitter  } from '@angular/core';
import {CourseServiceService} from '../course-service.service';
import {COURSE} from '../course';
import {NgForm} from '@angular/forms';

@Component({
  selector: 'app-update-modal',
  templateUrl: './update-modal.component.html',
  styleUrls: ['./update-modal.component.css']
})
export class UpdateModalComponent implements OnInit {

  constructor(private courseService:CourseServiceService) { }
  @Input() id:number;
  name:string;
  time:string;
  durtn:number;
  price:number;

  ngOnInit() {
    this.courseService.searchCourse(this.id).subscribe((data)=>{
        this.id=data.id;
        this.name=data.name;
        this.time=data.time;
        this.durtn=data.duration;
        this.price=data.price;
    });
  }

  

  course: COURSE;
  @Output() updateEvent = new EventEmitter<COURSE>();



  resetForm(form:NgForm){
    form.resetForm();
  }
  updateCourseDetails(){
    console.log("Update Called");
    this.course={
      id:this.id,
      name:this.name,
      price:this.price,
      duration:this.durtn,
      time:this.time
    }
    this.updateEvent.emit(this.course)
  }
}
