import React, { Component } from 'react';

class Mayank extends Component {
    render() {
        return (
            <li>
                user is- {this.props.mayankuser}
            </li>
        );
    }
}

export default Mayank;
