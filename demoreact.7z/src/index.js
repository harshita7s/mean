import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import Mayank from './mayank';
import registerServiceWorker from './registerServiceWorker';

 this.state={
      mayankuser:["misti","kuldeep","mayank","nandu"]
    };



// function addStateuser(){
//     var flagstate=this.state.mayankuser;
//     flagstate.push(ref.newUser.value);
//     this.setState({mayankuser:flagstate})
// }

ReactDOM.render(<App user={this.state.mayankuser} />, document.getElementById('root'));
registerServiceWorker();
