import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Mayank from './mayank';

import user from '../src/user.png';
import guest from '../src/guest.png';

class App extends Component {
  render() {
    var userComponent = this.props.user.map(a=>userItem(a));
    function userItem(a){
      return <Mayank mayankuser={a}/>
    }
    return (<div>
      please login<br />
      <ol>
  {userComponent}

      </ol>
    </div>);
  }
}

export default App;
